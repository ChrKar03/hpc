Christos Karagiannis 3544
Ioannis Sideris 3418
Athanasios Gerampinis 3466

To run the tests, execute ./test_omp.sh

Run ./test_omp.sh -h to reveal the variety of options avaliable.

The script creates a directory runs/ and runs/logs were
it stores the average of 10 executions of each test. You can
then run the python script provided to plot the results.